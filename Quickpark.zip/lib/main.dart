import 'package:flutter/material.dart';

void main() => runApp(const QuickParkApp());

const Color kNavy = Color(0xFF12233F);
const Color kBlue = Color(0xFF356CF6);
const Color kBg = Color(0xFFF5F7FB);
const Color kGreen = Color(0xFF1EAA75);

class QuickParkApp extends StatelessWidget {
  const QuickParkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QuickPark',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: kBg,
        colorScheme: ColorScheme.fromSeed(seedColor: kBlue),
        appBarTheme: const AppBarTheme(
          backgroundColor: kBg,
          foregroundColor: kNavy,
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE4E9F2)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: kBlue, width: 1.5),
          ),
        ),
      ),
      home: const LoginPage(),
    );
  }
}

class ParkingPlace {
  final String id;
  final String name;
  final String address;
  final String area;
  final double price;
  final double distance;
  final int totalSlots;
  final List<String> facilities;
  const ParkingPlace({
    required this.id,
    required this.name,
    required this.address,
    required this.area,
    required this.price,
    required this.distance,
    required this.totalSlots,
    required this.facilities,
  });
}

const List<ParkingPlace> demoPlaces = [
  ParkingPlace(
    id: 'qp1',
    name: 'City Centre Parking',
    address: 'MG Road, Vijayawada',
    area: 'Vijayawada',
    price: 30,
    distance: 0.8,
    totalSlots: 24,
    facilities: ['CCTV', 'Security', 'EV Charging'],
  ),
  ParkingPlace(
    id: 'qp2',
    name: 'Railway Station Parking',
    address: 'Railway Station Road',
    area: 'Vijayawada',
    price: 25,
    distance: 1.4,
    totalSlots: 18,
    facilities: ['CCTV', 'Security'],
  ),
  ParkingPlace(
    id: 'qp3',
    name: 'Airport Smart Parking',
    address: 'Airport Road',
    area: 'Gannavaram',
    price: 50,
    distance: 5.2,
    totalSlots: 32,
    facilities: ['CCTV', 'Security', 'EV Charging'],
  ),
  ParkingPlace(
    id: 'qp4',
    name: 'Mall Basement Parking',
    address: 'Benz Circle',
    area: 'Vijayawada',
    price: 35,
    distance: 2.1,
    totalSlots: 40,
    facilities: ['CCTV', 'Security'],
  ),
  ParkingPlace(
    id: 'qp5',
    name: 'Beachfront Parking',
    address: 'Beach Road',
    area: 'Visakhapatnam',
    price: 40,
    distance: 62,
    totalSlots: 28,
    facilities: ['CCTV', 'EV Charging'],
  ),
  ParkingPlace(
    id: 'qp6',
    name: 'Central Market Parking',
    address: 'Abids Main Road',
    area: 'Hyderabad',
    price: 35,
    distance: 275,
    totalSlots: 36,
    facilities: ['CCTV', 'Security'],
  ),
  ParkingPlace(
    id: 'qp7',
    name: 'Tech Park Parking',
    address: 'Whitefield Main Road',
    area: 'Bengaluru',
    price: 45,
    distance: 520,
    totalSlots: 50,
    facilities: ['CCTV', 'Security', 'EV Charging'],
  ),
  ParkingPlace(
    id: 'qp8',
    name: 'Downtown Parking Hub',
    address: 'Connaught Place',
    area: 'New Delhi',
    price: 60,
    distance: 1450,
    totalSlots: 44,
    facilities: ['CCTV', 'Security', 'EV Charging'],
  ),
];

class ParkingBooking {
  final String id;
  final ParkingPlace place;
  final String slot;
  final String vehicle;
  final DateTime date;
  final TimeOfDay start;
  final TimeOfDay end;
  final double total;
  String status;
  ParkingBooking({
    required this.id,
    required this.place,
    required this.slot,
    required this.vehicle,
    required this.date,
    required this.start,
    required this.end,
    required this.total,
    this.status = 'Confirmed',
  });
}

class Vehicle {
  String name;
  String number;
  String type;
  Vehicle(this.name, this.number, this.type);
}

class DemoStore {
  static String userName = 'Parking Guest';
  static String email = 'guest@example.com';
  static final List<ParkingBooking> bookings = [];
  static final List<Vehicle> vehicles = [
    Vehicle('My Car', 'AP 16 AB 1234', 'Car'),
    Vehicle('My Scooter', 'AP 16 CD 5678', 'Bike'),
  ];
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _obscure = true;
  bool _signUp = false;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  void _continue() {
    if (_email.text.trim().isEmpty ||
        !_email.text.contains('@') ||
        _password.text.length < 4 ||
        (_signUp && _name.text.trim().isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter valid details to continue.')),
      );
      return;
    }
    DemoStore.email = _email.text.trim();
    DemoStore.userName =
        _signUp ? _name.text.trim() : _email.text.split('@').first;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const MainShell()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 92,
                    width: 92,
                    decoration: BoxDecoration(
                      color: kBlue,
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: [
                        BoxShadow(
                            color: kBlue.withOpacity(.22),
                            blurRadius: 22,
                            offset: const Offset(0, 10))
                      ],
                    ),
                    child: const Icon(Icons.local_parking_rounded,
                        color: Colors.white, size: 54),
                  ),
                  const SizedBox(height: 28),
                  const Text('QuickPark',
                      style: TextStyle(
                          fontSize: 34,
                          fontWeight: FontWeight.w800,
                          color: kNavy)),
                  const SizedBox(height: 8),
                  Text(
                      _signUp
                          ? 'Create an account to get started.'
                          : 'Find your spot. Park with confidence.',
                      style:
                          const TextStyle(color: Colors.black54, fontSize: 16)),
                  const SizedBox(height: 30),
                  if (_signUp) ...[
                    TextField(
                        controller: _name,
                        decoration: const InputDecoration(
                            labelText: 'Full name',
                            prefixIcon: Icon(Icons.person_outline))),
                    const SizedBox(height: 14),
                  ],
                  TextField(
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                        labelText: 'Email address',
                        prefixIcon: Icon(Icons.email_outlined)),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _password,
                    obscureText: _obscure,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => _obscure = !_obscure),
                        icon: Icon(_obscure
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined),
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  FilledButton(
                    onPressed: _continue,
                    style: FilledButton.styleFrom(
                        backgroundColor: kBlue,
                        padding: const EdgeInsets.symmetric(vertical: 17),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14))),
                    child: Text(_signUp ? 'Create account' : 'Login',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  TextButton(
                    onPressed: () => setState(() => _signUp = !_signUp),
                    child: Text(_signUp
                        ? 'Already have an account? Login'
                        : 'New to QuickPark? Create account'),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                      'Demo app: account details are not sent to a server.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.black45, fontSize: 12)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;
  final List<String> _titles = [
    'Find parking',
    'My bookings',
    'My vehicles',
    'Profile'
  ];

  void _refresh() => setState(() {});
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
          onOpenBooking: (booking) {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => BookingDetailsPage(booking: booking)));
          },
          onChanged: _refresh),
      BookingsPage(onChanged: _refresh),
      VehiclesPage(onChanged: _refresh),
      ProfilePage(onChanged: _refresh),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          const Icon(Icons.local_parking_rounded, color: kBlue, size: 28),
          const SizedBox(width: 8),
          Text(_titles[_index],
              style: const TextStyle(fontWeight: FontWeight.w800)),
        ]),
      ),
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.search_rounded), label: 'Explore'),
          NavigationDestination(
              icon: Icon(Icons.confirmation_number_outlined),
              label: 'Bookings'),
          NavigationDestination(
              icon: Icon(Icons.directions_car_outlined), label: 'Vehicles'),
          NavigationDestination(
              icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final ValueChanged<ParkingBooking> onOpenBooking;
  final VoidCallback onChanged;
  const HomePage(
      {super.key, required this.onOpenBooking, required this.onChanged});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _search = TextEditingController();
  String _area = 'All locations';
  final List<String> _areas = const [
    'All locations',
    'Vijayawada',
    'Gannavaram',
    'Visakhapatnam',
    'Hyderabad',
    'Bengaluru',
    'New Delhi'
  ];

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = _search.text.toLowerCase().trim();
    final places = demoPlaces.where((p) {
      final matchesArea = _area == 'All locations' || p.area == _area;
      final matchesQuery = query.isEmpty ||
          '${p.name} ${p.address} ${p.area}'.toLowerCase().contains(query);
      return matchesArea && matchesQuery;
    }).toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 4, 18, 22),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
                colors: [Color(0xFF173B78), Color(0xFF356CF6)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(24),
          ),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Parking made simple',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 23,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('Discover a spot and book it in a few taps.',
                style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 18),
            Row(children: [
              const Icon(Icons.shield_outlined, color: Colors.white, size: 20),
              const SizedBox(width: 8),
              const Expanded(
                  child: Text('Safer parking, less circling',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w600))),
              Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      color: Colors.white.withOpacity(.15),
                      borderRadius: BorderRadius.circular(14)),
                  child: const Icon(Icons.local_parking,
                      color: Colors.white, size: 26)),
            ]),
          ]),
        ),
        const SizedBox(height: 22),
        TextField(
          controller: _search,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            hintText: 'Search parking, area or city',
            prefixIcon: const Icon(Icons.search),
            suffixIcon: IconButton(
              tooltip: 'Clear search',
              onPressed: () {
                _search.clear();
                setState(() {});
              },
              icon: const Icon(Icons.close),
            ),
          ),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _area,
          decoration: const InputDecoration(
              labelText: 'Choose location',
              prefixIcon: Icon(Icons.location_on_outlined)),
          items: _areas
              .map((a) => DropdownMenuItem(value: a, child: Text(a)))
              .toList(),
          onChanged: (value) =>
              setState(() => _area = value ?? 'All locations'),
        ),
        const SizedBox(height: 24),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Nearby parking',
              style: TextStyle(
                  fontSize: 20, fontWeight: FontWeight.w800, color: kNavy)),
          Text('${places.length} places',
              style: const TextStyle(color: Colors.black54)),
        ]),
        const SizedBox(height: 12),
        if (places.isEmpty)
          const Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                  'No demo locations match. Try another city or search term.',
                  textAlign: TextAlign.center))
        else
          ...places.map((place) => ParkingCard(
                place: place,
                onTap: () async {
                  await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => ParkingDetailsPage(
                              place: place,
                              onBooked: (booking) {
                                widget.onChanged();
                                widget.onOpenBooking(booking);
                              })));
                  setState(() {});
                },
              )),
        const SizedBox(height: 8),
        const Text(
            'Locations shown are sample demo data, not live availability.',
            style: TextStyle(fontSize: 12, color: Colors.black45)),
      ],
    );
  }
}

class ParkingCard extends StatelessWidget {
  final ParkingPlace place;
  final VoidCallback onTap;
  const ParkingCard({super.key, required this.place, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      color: Colors.white,
      elevation: 0,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: Color(0xFFE8ECF4))),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            height: 112,
            width: double.infinity,
            decoration: const BoxDecoration(
                gradient: LinearGradient(
                    colors: [Color(0xFFDDE8FF), Color(0xFFEFF4FF)])),
            child: Stack(children: [
              const Positioned(
                  right: 18,
                  top: 12,
                  child: Icon(Icons.location_city_rounded,
                      size: 84, color: Color(0x55356CF6))),
              Positioned(
                  left: 18,
                  top: 18,
                  child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30)),
                      child: const Row(children: [
                        Icon(Icons.verified_rounded, color: kGreen, size: 16),
                        SizedBox(width: 5),
                        Text('Parking area',
                            style: TextStyle(
                                fontWeight: FontWeight.w700, fontSize: 12))
                      ]))),
              Positioned(
                  left: 18,
                  bottom: 14,
                  child: Text('${place.totalSlots} demo slots',
                      style: const TextStyle(
                          color: kNavy, fontWeight: FontWeight.w800))),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Text(place.name,
                          style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                              color: kNavy)),
                      const SizedBox(height: 6),
                      Row(children: [
                        const Icon(Icons.location_on_outlined,
                            size: 16, color: Colors.black45),
                        const SizedBox(width: 4),
                        Expanded(
                            child: Text(place.address,
                                style: const TextStyle(color: Colors.black54),
                                maxLines: 2))
                      ]),
                    ])),
                const SizedBox(width: 8),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('₹${place.price.toStringAsFixed(0)}',
                      style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: kBlue)),
                  const Text('/ hour',
                      style: TextStyle(fontSize: 12, color: Colors.black54)),
                ]),
              ]),
              const SizedBox(height: 14),
              Wrap(spacing: 7, runSpacing: 7, children: [
                _tag(Icons.near_me_outlined,
                    '${place.distance.toStringAsFixed(1)} km demo'),
                ...place.facilities.take(2).map((f) => _tag(
                    f == 'EV Charging'
                        ? Icons.ev_station
                        : f == 'CCTV'
                            ? Icons.videocam_outlined
                            : Icons.shield_outlined,
                    f)),
              ]),
              const SizedBox(height: 14),
              const Row(children: [
                Text('View slots',
                    style:
                        TextStyle(color: kBlue, fontWeight: FontWeight.w800)),
                Spacer(),
                Icon(Icons.arrow_forward_rounded, color: kBlue, size: 20)
              ]),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _tag(IconData icon, String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(
            color: const Color(0xFFF1F5FC),
            borderRadius: BorderRadius.circular(30)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 14, color: kNavy),
          const SizedBox(width: 5),
          Text(text,
              style: const TextStyle(
                  fontSize: 11, color: kNavy, fontWeight: FontWeight.w600))
        ]),
      );
}

class ParkingDetailsPage extends StatefulWidget {
  final ParkingPlace place;
  final ValueChanged<ParkingBooking> onBooked;
  const ParkingDetailsPage(
      {super.key, required this.place, required this.onBooked});
  @override
  State<ParkingDetailsPage> createState() => _ParkingDetailsPageState();
}

class _ParkingDetailsPageState extends State<ParkingDetailsPage> {
  String? _selectedSlot;
  DateTime _date = DateTime.now();
  TimeOfDay _start = const TimeOfDay(hour: 10, minute: 0);
  TimeOfDay _end = const TimeOfDay(hour: 11, minute: 0);
  String? _vehicle;
  final Set<String> _occupied = {};

  List<String> get _slots =>
      List.generate(widget.place.totalSlots, (i) => 'P${i + 1}');

  bool _sameTime(TimeOfDay a, TimeOfDay b) =>
      a.hour == b.hour && a.minute == b.minute;
  bool get _validTime =>
      _end.hour * 60 + _end.minute > _start.hour * 60 + _start.minute;

  int get _durationMinutes =>
      (_end.hour * 60 + _end.minute) - (_start.hour * 60 + _start.minute);

  Future<void> _chooseDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate:
          _date.isBefore(DateTime(now.year, now.month, now.day)) ? now : _date,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: DateTime(now.year + 1, 12, 31),
      helpText: 'Choose parking date',
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _chooseTime({required bool isStart}) async {
    final picked = await showTimePicker(
        context: context,
        initialTime: isStart ? _start : _end,
        helpText: isStart ? 'Select start time' : 'Select end time');
    if (picked != null) {
      setState(() {
        if (isStart) {
          _start = picked;
          if (_end.hour * 60 + _end.minute <=
              _start.hour * 60 + _start.minute) {
            final mins = (_start.hour * 60 + _start.minute + 60) % (24 * 60);
            _end = TimeOfDay(hour: mins ~/ 60, minute: mins % 60);
          }
        } else {
          _end = picked;
        }
      });
    }
  }

  void _book() {
    if (_selectedSlot == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please select a parking slot.')));
      return;
    }
    if (!_validTime) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('End time must be later than start time.')));
      return;
    }
    if (DemoStore.vehicles.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please add a vehicle first.')));
      return;
    }
    _vehicle ??= DemoStore.vehicles.first.number;
    final hours = _durationMinutes / 60;
    final total = widget.place.price * hours;
    final booking = ParkingBooking(
      id: 'QP${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}',
      place: widget.place,
      slot: _selectedSlot!,
      vehicle: _vehicle!,
      date: _date,
      start: _start,
      end: _end,
      total: total,
    );
    DemoStore.bookings.insert(0, booking);
    _occupied.add(_selectedSlot!);
    widget.onBooked(booking);
  }

  @override
  Widget build(BuildContext context) {
    final freeCount = _slots.where((s) => !_occupied.contains(s)).length;
    return Scaffold(
      appBar: AppBar(title: const Text('Parking details')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 28),
        children: [
          Container(
            height: 165,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Color(0xFF173B78), Color(0xFF5687FF)]),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Stack(children: [
              const Positioned(
                  right: 18,
                  top: 15,
                  child: Icon(Icons.local_parking_rounded,
                      size: 115, color: Color(0x44FFFFFF))),
              Positioned(
                  left: 20,
                  bottom: 20,
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.place.name,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w800)),
                        const SizedBox(height: 7),
                        Row(children: [
                          const Icon(Icons.location_on_outlined,
                              color: Colors.white70, size: 17),
                          const SizedBox(width: 5),
                          Text(widget.place.address,
                              style: const TextStyle(color: Colors.white70))
                        ]),
                      ])),
            ]),
          ),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(
                child: _stat(Icons.payments_outlined,
                    '₹${widget.place.price.toStringAsFixed(0)}', 'Per hour')),
            const SizedBox(width: 10),
            Expanded(
                child: _stat(
                    Icons.local_parking_outlined, '$freeCount', 'Slots shown')),
            const SizedBox(width: 10),
            Expanded(
                child: _stat(Icons.near_me_outlined,
                    '${widget.place.distance} km', 'Demo distance')),
          ]),
          const SizedBox(height: 24),
          const Text('Facilities',
              style: TextStyle(
                  fontSize: 19, fontWeight: FontWeight.w800, color: kNavy)),
          const SizedBox(height: 12),
          Wrap(
              spacing: 9,
              runSpacing: 9,
              children: widget.place.facilities
                  .map((f) => Chip(
                        avatar: Icon(
                            f == 'EV Charging'
                                ? Icons.ev_station
                                : f == 'CCTV'
                                    ? Icons.videocam_outlined
                                    : Icons.shield_outlined,
                            size: 18,
                            color: kBlue),
                        label: Text(f),
                        backgroundColor: Colors.white,
                        side: const BorderSide(color: Color(0xFFE4E9F2)),
                      ))
                  .toList()),
          const SizedBox(height: 24),
          const Text('Choose a slot',
              style: TextStyle(
                  fontSize: 19, fontWeight: FontWeight.w800, color: kNavy)),
          const SizedBox(height: 7),
          const Row(children: [
            _Legend(color: kGreen, text: 'Available'),
            SizedBox(width: 14),
            _Legend(color: kBlue, text: 'Selected'),
            SizedBox(width: 14),
            _Legend(color: Colors.grey, text: 'Booked (demo)'),
          ]),
          const SizedBox(height: 14),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _slots.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 1.25),
            itemBuilder: (context, index) {
              final slot = _slots[index];
              final taken = _occupied.contains(slot);
              final selected = _selectedSlot == slot;
              final color = taken
                  ? Colors.grey
                  : selected
                      ? kBlue
                      : kGreen;
              return InkWell(
                borderRadius: BorderRadius.circular(13),
                onTap:
                    taken ? null : () => setState(() => _selectedSlot = slot),
                child: Container(
                  decoration: BoxDecoration(
                      color: color.withOpacity(selected || taken ? .13 : .08),
                      border: Border.all(color: color, width: selected ? 2 : 1),
                      borderRadius: BorderRadius.circular(13)),
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.local_parking_rounded,
                            color: color, size: 21),
                        const SizedBox(height: 4),
                        Text(slot,
                            style: TextStyle(
                                color: color, fontWeight: FontWeight.w800)),
                      ]),
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          const Text('Booking details',
              style: TextStyle(
                  fontSize: 19, fontWeight: FontWeight.w800, color: kNavy)),
          const SizedBox(height: 12),
          _pickerTile(Icons.calendar_month_outlined, 'Date',
              '${_date.day}/${_date.month}/${_date.year}', _chooseDate),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
                child: _pickerTile(Icons.login_rounded, 'Start time',
                    _start.format(context), () => _chooseTime(isStart: true))),
            const SizedBox(width: 10),
            Expanded(
                child: _pickerTile(Icons.logout_rounded, 'End time',
                    _end.format(context), () => _chooseTime(isStart: false))),
          ]),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: _vehicle ??
                (DemoStore.vehicles.isNotEmpty
                    ? DemoStore.vehicles.first.number
                    : null),
            decoration: const InputDecoration(
                labelText: 'Select vehicle',
                prefixIcon: Icon(Icons.directions_car_outlined)),
            items: DemoStore.vehicles
                .map((v) => DropdownMenuItem(
                    value: v.number, child: Text('${v.name} · ${v.number}')))
                .toList(),
            onChanged: (value) => setState(() => _vehicle = value),
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(17),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(17),
                border: Border.all(color: const Color(0xFFE4E9F2))),
            child: Row(children: [
              const Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    Text('Estimated total',
                        style: TextStyle(color: Colors.black54)),
                    SizedBox(height: 4),
                    Text('Price × parking duration',
                        style: TextStyle(fontSize: 12, color: Colors.black45)),
                  ])),
              Text(
                  _validTime
                      ? '₹${(widget.place.price * _durationMinutes / 60).toStringAsFixed(2)}'
                      : 'Check time',
                  style: const TextStyle(
                      fontSize: 23, fontWeight: FontWeight.w800, color: kNavy)),
            ]),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _book,
            icon: const Icon(Icons.check_circle_outline),
            label: const Text('Confirm demo booking'),
            style: FilledButton.styleFrom(
                backgroundColor: kBlue,
                padding: const EdgeInsets.symmetric(vertical: 17),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14))),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => DirectionsDemoPage(place: widget.place))),
            icon: const Icon(Icons.directions_outlined),
            label: const Text('View directions (demo)'),
            style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14))),
          ),
          const SizedBox(height: 12),
          const Text(
              'Slot availability and booking are stored only in this running demo. They are not shared with other users.',
              style: TextStyle(color: Colors.black45, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _stat(IconData icon, String value, String label) => Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE8ECF4))),
        child: Column(children: [
          Icon(icon, color: kBlue),
          const SizedBox(height: 7),
          Text(value,
              style:
                  const TextStyle(fontWeight: FontWeight.w800, color: kNavy)),
          const SizedBox(height: 3),
          Text(label,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 11, color: Colors.black54))
        ]),
      );

  Widget _pickerTile(
          IconData icon, String title, String value, VoidCallback onTap) =>
      InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFE4E9F2))),
          child: Row(children: [
            Icon(icon, color: kBlue, size: 21),
            const SizedBox(width: 9),
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(title,
                      style:
                          const TextStyle(fontSize: 11, color: Colors.black54)),
                  const SizedBox(height: 4),
                  Text(value,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                ])),
            const Icon(Icons.keyboard_arrow_down, size: 18),
          ]),
        ),
      );
}

class _Legend extends StatelessWidget {
  final Color color;
  final String text;
  const _Legend({required this.color, required this.text});
  @override
  Widget build(BuildContext context) =>
      Row(mainAxisSize: MainAxisSize.min, children: [
        Container(
            width: 9,
            height: 9,
            decoration: BoxDecoration(
                color: color, borderRadius: BorderRadius.circular(3))),
        const SizedBox(width: 5),
        Text(text, style: const TextStyle(fontSize: 11, color: Colors.black54)),
      ]);
}

class DirectionsDemoPage extends StatelessWidget {
  final ParkingPlace place;
  const DirectionsDemoPage({super.key, required this.place});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Directions')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child:
            Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(
            height: 260,
            decoration: BoxDecoration(
                color: const Color(0xFFE5EDFF),
                borderRadius: BorderRadius.circular(24)),
            child: Stack(alignment: Alignment.center, children: [
              const Icon(Icons.map_outlined,
                  size: 145, color: Color(0xFF9DB8F8)),
              Positioned(
                  left: 35, top: 35, child: _mapDot(Icons.my_location, kBlue)),
              Positioned(
                  right: 48,
                  bottom: 38,
                  child: _mapDot(Icons.local_parking, kGreen)),
              Positioned(
                  left: 64,
                  top: 70,
                  child: Container(width: 150, height: 3, color: kBlue)),
              Positioned(
                  left: 90,
                  top: 73,
                  child: Transform.rotate(
                      angle: .72,
                      child: Container(width: 130, height: 3, color: kBlue))),
            ]),
          ),
          const SizedBox(height: 22),
          const Text('Destination', style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 5),
          Text(place.name,
              style: const TextStyle(
                  fontSize: 23, fontWeight: FontWeight.w800, color: kNavy)),
          const SizedBox(height: 5),
          Text(place.address, style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 16),
          const ListTile(
              leading: Icon(Icons.info_outline, color: kBlue),
              title: Text('Demo route only'),
              subtitle: Text(
                  'This screen is illustrative. It does not use GPS, calculate a real route, or provide live traffic.')),
          const Spacer(),
          FilledButton.icon(
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content:
                        Text('Connect a maps API to enable real navigation.'))),
            icon: const Icon(Icons.navigation_outlined),
            label: const Text('Navigation unavailable in demo'),
            style: FilledButton.styleFrom(
                backgroundColor: kBlue,
                padding: const EdgeInsets.symmetric(vertical: 16)),
          ),
        ]),
      ),
    );
  }

  Widget _mapDot(IconData icon, Color color) => Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(color: color.withOpacity(.25), blurRadius: 12)
            ]),
        child: Icon(icon, color: Colors.white, size: 22),
      );
}

class BookingsPage extends StatelessWidget {
  final VoidCallback onChanged;
  const BookingsPage({super.key, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    final bookings = DemoStore.bookings;
    if (bookings.isEmpty) {
      return const EmptyState(
          icon: Icons.confirmation_number_outlined,
          title: 'No bookings yet',
          subtitle:
              'Choose a parking place and confirm a demo booking to see it here.');
    }
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text('${bookings.length} booking${bookings.length == 1 ? '' : 's'}',
            style: const TextStyle(
                fontSize: 20, fontWeight: FontWeight.w800, color: kNavy)),
        const SizedBox(height: 12),
        ...bookings.map((b) => BookingCard(
              booking: b,
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => BookingDetailsPage(booking: b))),
              onCancel: b.status == 'Confirmed'
                  ? () {
                      b.status = 'Cancelled';
                      onChanged();
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                          content: Text('Demo booking cancelled.')));
                    }
                  : null,
            )),
      ],
    );
  }
}

class BookingCard extends StatelessWidget {
  final ParkingBooking booking;
  final VoidCallback onTap;
  final VoidCallback? onCancel;
  const BookingCard(
      {super.key, required this.booking, required this.onTap, this.onCancel});
  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 13),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: Color(0xFFE5EAF2))),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Row(children: [
              Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                      color: const Color(0xFFEAF0FF),
                      borderRadius: BorderRadius.circular(14)),
                  child:
                      const Icon(Icons.local_parking, color: kBlue, size: 27)),
              const SizedBox(width: 12),
              Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    Text(booking.place.name,
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, color: kNavy)),
                    const SizedBox(height: 4),
                    Text(booking.place.address,
                        style: const TextStyle(
                            color: Colors.black54, fontSize: 12)),
                  ])),
              Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                  decoration: BoxDecoration(
                      color: booking.status == 'Confirmed'
                          ? const Color(0xFFE7F8F0)
                          : const Color(0xFFF2F3F5),
                      borderRadius: BorderRadius.circular(20)),
                  child: Text(booking.status,
                      style: TextStyle(
                          color: booking.status == 'Confirmed'
                              ? kGreen
                              : Colors.grey,
                          fontSize: 11,
                          fontWeight: FontWeight.w800))),
            ]),
            const Divider(height: 25),
            Row(children: [
              _bookingInfo('Slot', booking.slot),
              _bookingInfo('Date',
                  '${booking.date.day}/${booking.date.month}/${booking.date.year}'),
              _bookingInfo('Total', '₹${booking.total.toStringAsFixed(2)}'),
            ]),
            if (onCancel != null) ...[
              const SizedBox(height: 10),
              Align(
                  alignment: Alignment.centerRight,
                  child: TextButton.icon(
                      onPressed: onCancel,
                      icon: const Icon(Icons.cancel_outlined, size: 18),
                      label: const Text('Cancel booking'),
                      style: TextButton.styleFrom(
                          foregroundColor: Colors.redAccent))),
            ],
          ]),
        ),
      ),
    );
  }

  Widget _bookingInfo(String label, String value) => Expanded(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label,
            style: const TextStyle(fontSize: 11, color: Colors.black54)),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(fontWeight: FontWeight.w800, color: kNavy)),
      ]));
}

class BookingDetailsPage extends StatelessWidget {
  final ParkingBooking booking;
  const BookingDetailsPage({super.key, required this.booking});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Booking confirmation')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(25),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFFE5EAF2))),
            child: Column(children: [
              Container(
                  width: 72,
                  height: 72,
                  decoration: const BoxDecoration(
                      color: Color(0xFFE5F8EF), shape: BoxShape.circle),
                  child:
                      const Icon(Icons.check_rounded, color: kGreen, size: 42)),
              const SizedBox(height: 15),
              const Text('Booking created!',
                  style: TextStyle(
                      fontSize: 24, fontWeight: FontWeight.w800, color: kNavy)),
              const SizedBox(height: 6),
              const Text('Your demo booking details are below.',
                  style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 20),
              Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                      color: const Color(0xFFF2F6FF),
                      borderRadius: BorderRadius.circular(18)),
                  child: Column(children: [
                    const Text('YOUR PARKING SLOT',
                        style: TextStyle(
                            fontSize: 11,
                            color: Colors.black54,
                            letterSpacing: 1)),
                    const SizedBox(height: 5),
                    Text(booking.slot,
                        style: const TextStyle(
                            fontSize: 38,
                            fontWeight: FontWeight.w900,
                            color: kBlue)),
                    Text(booking.id,
                        style: const TextStyle(color: Colors.black54)),
                  ])),
              const SizedBox(height: 18),
              _detail('Parking location', booking.place.name),
              _detail('Address', booking.place.address),
              _detail('Date',
                  '${booking.date.day}/${booking.date.month}/${booking.date.year}'),
              _detail('Start time', booking.start.format(context)),
              _detail('End time', booking.end.format(context)),
              _detail('Vehicle', booking.vehicle),
              _detail('Status', booking.status),
              const Divider(height: 28),
              Row(children: [
                const Expanded(
                    child: Text('Total amount',
                        style: TextStyle(fontWeight: FontWeight.w700))),
                Text('₹${booking.total.toStringAsFixed(2)}',
                    style: const TextStyle(
                        fontSize: 23,
                        color: kBlue,
                        fontWeight: FontWeight.w900))
              ]),
            ]),
          ),
          const SizedBox(height: 16),
          FilledButton(
              onPressed: () =>
                  Navigator.popUntil(context, (route) => route.isFirst),
              style: FilledButton.styleFrom(
                  backgroundColor: kBlue,
                  padding: const EdgeInsets.symmetric(vertical: 16)),
              child: const Text('Back to QuickPark')),
        ],
      ),
    );
  }

  Widget _detail(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
              child:
                  Text(label, style: const TextStyle(color: Colors.black54))),
          const SizedBox(width: 14),
          Expanded(
              child: Text(value,
                  textAlign: TextAlign.end,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, color: kNavy))),
        ]),
      );
}

class VehiclesPage extends StatefulWidget {
  final VoidCallback onChanged;
  const VehiclesPage({super.key, required this.onChanged});
  @override
  State<VehiclesPage> createState() => _VehiclesPageState();
}

class _VehiclesPageState extends State<VehiclesPage> {
  Future<void> _editVehicle({Vehicle? vehicle}) async {
    final name = TextEditingController(text: vehicle?.name ?? '');
    final number = TextEditingController(text: vehicle?.number ?? '');
    String type = vehicle?.type ?? 'Car';
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
          builder: (context, setDialogState) => AlertDialog(
                title: Text(vehicle == null ? 'Add vehicle' : 'Edit vehicle'),
                content: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextField(
                      controller: name,
                      decoration:
                          const InputDecoration(labelText: 'Vehicle name')),
                  const SizedBox(height: 10),
                  TextField(
                      controller: number,
                      textCapitalization: TextCapitalization.characters,
                      decoration: const InputDecoration(
                          labelText: 'Registration number')),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: type,
                    decoration:
                        const InputDecoration(labelText: 'Vehicle type'),
                    items: const ['Car', 'Bike', 'Scooter', 'EV', 'Other']
                        .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                        .toList(),
                    onChanged: (v) => setDialogState(() => type = v ?? 'Car'),
                  ),
                ])),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(dialogContext, false),
                      child: const Text('Cancel')),
                  FilledButton(
                      onPressed: () {
                        if (name.text.trim().isEmpty ||
                            number.text.trim().isEmpty) return;
                        Navigator.pop(dialogContext, true);
                      },
                      child: const Text('Save')),
                ],
              )),
    );
    if (result == true) {
      if (vehicle == null) {
        DemoStore.vehicles.add(
            Vehicle(name.text.trim(), number.text.trim().toUpperCase(), type));
      } else {
        vehicle.name = name.text.trim();
        vehicle.number = number.text.trim().toUpperCase();
        vehicle.type = type;
      }
      setState(() {});
      widget.onChanged();
    }
    name.dispose();
    number.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final vehicles = DemoStore.vehicles;
    return ListView(padding: const EdgeInsets.all(18), children: [
      Row(children: [
        const Expanded(
            child: Text('Your vehicles',
                style: TextStyle(
                    fontSize: 21, fontWeight: FontWeight.w800, color: kNavy))),
        FilledButton.icon(
            onPressed: () => _editVehicle(),
            icon: const Icon(Icons.add, size: 18),
            label: const Text('Add')),
      ]),
      const SizedBox(height: 8),
      const Text('Manage the vehicles you use for parking bookings.',
          style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 18),
      if (vehicles.isEmpty)
        const EmptyState(
            icon: Icons.directions_car_outlined,
            title: 'No vehicles added',
            subtitle: 'Add a vehicle to start a booking.'),
      ...vehicles.map((v) => Card(
            color: Colors.white,
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 12),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
                side: const BorderSide(color: Color(0xFFE5EAF2))),
            child: ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              leading: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                      color: const Color(0xFFEAF0FF),
                      borderRadius: BorderRadius.circular(14)),
                  child: Icon(
                      v.type == 'Bike' || v.type == 'Scooter'
                          ? Icons.two_wheeler
                          : Icons.directions_car,
                      color: kBlue)),
              title: Text(v.name,
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, color: kNavy)),
              subtitle: Text('${v.number}\n${v.type}'),
              isThreeLine: true,
              trailing: PopupMenuButton<String>(
                onSelected: (choice) {
                  if (choice == 'edit') _editVehicle(vehicle: v);
                  if (choice == 'delete') {
                    setState(() => DemoStore.vehicles.remove(v));
                    widget.onChanged();
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('Edit vehicle')),
                  PopupMenuItem(value: 'delete', child: Text('Delete vehicle')),
                ],
              ),
            ),
          )),
    ]);
  }
}

class ProfilePage extends StatelessWidget {
  final VoidCallback onChanged;
  const ProfilePage({super.key, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(18), children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
            color: kNavy, borderRadius: BorderRadius.circular(22)),
        child: Row(children: [
          Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.15), shape: BoxShape.circle),
              child: const Icon(Icons.person, color: Colors.white, size: 34)),
          const SizedBox(width: 14),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(DemoStore.userName,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 19,
                        fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(DemoStore.email,
                    style: const TextStyle(color: Colors.white70)),
              ])),
        ]),
      ),
      const SizedBox(height: 20),
      const Text('Account',
          style: TextStyle(
              fontSize: 17, fontWeight: FontWeight.w800, color: kNavy)),
      const SizedBox(height: 10),
      _profileItem(context, Icons.person_outline, 'Edit profile',
          'Update your display name', () => _editProfile(context)),
      _profileItem(
          context,
          Icons.lock_outline,
          'Privacy & security',
          'Demo privacy information',
          () => _showInfo(context, 'Privacy & security',
              'This demo stores profile, vehicle and booking data in memory on this device while the app runs. It has no backend, account authentication service, or online data sync. A production app needs secure authentication, server-side access controls, a privacy policy and account deletion.')),
      _profileItem(
          context,
          Icons.help_outline,
          'Help & support',
          'QuickPark demo help',
          () => _showInfo(context, 'Help & support',
              'Search for a demo location, open a parking place, select a slot, choose a date and time, then confirm your booking. Manage vehicles from the Vehicles tab.')),
      _profileItem(
          context,
          Icons.info_outline,
          'About QuickPark',
          'Version 1.0 · College demo',
          () => _showInfo(context, 'About QuickPark',
              'QuickPark is a parking discovery and booking UI demo. Location listings, distance, slot availability and directions are sample data and are not connected to real parking providers.')),
      const SizedBox(height: 18),
      OutlinedButton.icon(
        onPressed: () async {
          final yes = await showDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                    title: const Text('Log out?'),
                    content: const Text('Return to the login screen?'),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(ctx, false),
                          child: const Text('Stay')),
                      FilledButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          child: const Text('Log out')),
                    ],
                  ));
          if (yes == true && context.mounted) {
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (_) => false);
          }
        },
        icon: const Icon(Icons.logout_rounded),
        label: const Text('Log out'),
        style: OutlinedButton.styleFrom(
            foregroundColor: Colors.redAccent,
            padding: const EdgeInsets.symmetric(vertical: 15),
            side: const BorderSide(color: Color(0xFFFFD9D9)),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14))),
      ),
    ]);
  }

  Widget _profileItem(BuildContext context, IconData icon, String title,
          String subtitle, VoidCallback onTap) =>
      Card(
        color: Colors.white,
        elevation: 0,
        margin: const EdgeInsets.only(bottom: 10),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: Color(0xFFE5EAF2))),
        child: ListTile(
          onTap: onTap,
          leading: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                  color: const Color(0xFFEAF0FF),
                  borderRadius: BorderRadius.circular(12)),
              child: Icon(icon, color: kBlue)),
          title: Text(title,
              style:
                  const TextStyle(fontWeight: FontWeight.w700, color: kNavy)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right, color: Colors.black45),
        ),
      );

  Future<void> _editProfile(BuildContext context) async {
    final name = TextEditingController(text: DemoStore.userName);
    final email = TextEditingController(text: DemoStore.email);
    final result = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: const Text('Edit profile'),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(
                    controller: name,
                    decoration:
                        const InputDecoration(labelText: 'Display name')),
                const SizedBox(height: 10),
                TextField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'Email')),
              ]),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: const Text('Cancel')),
                FilledButton(
                    onPressed: () {
                      if (name.text.trim().isEmpty || !email.text.contains('@'))
                        return;
                      Navigator.pop(ctx, true);
                    },
                    child: const Text('Save')),
              ],
            ));
    if (result == true) {
      DemoStore.userName = name.text.trim();
      DemoStore.email = email.text.trim();
      onChanged();
      if (context.mounted)
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Profile updated for this demo.')));
    }
    name.dispose();
    email.dispose();
  }

  void _showInfo(BuildContext context, String title, String message) {
    showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: Text(title),
              content: Text(message),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Close'))
              ],
            ));
  }
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const EmptyState(
      {super.key,
      required this.icon,
      required this.title,
      required this.subtitle});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
              width: 82,
              height: 82,
              decoration: const BoxDecoration(
                  color: Color(0xFFEAF0FF), shape: BoxShape.circle),
              child: Icon(icon, size: 38, color: kBlue)),
          const SizedBox(height: 17),
          Text(title,
              style: const TextStyle(
                  fontSize: 20, fontWeight: FontWeight.w800, color: kNavy),
              textAlign: TextAlign.center),
          const SizedBox(height: 8),
          Text(subtitle,
              style: const TextStyle(color: Colors.black54),
              textAlign: TextAlign.center),
        ]),
      ),
    );
  }
}
